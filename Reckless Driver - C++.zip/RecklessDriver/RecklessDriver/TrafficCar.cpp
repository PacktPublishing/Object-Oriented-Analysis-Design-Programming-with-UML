#include "TrafficCar.h"


namespace RecklessDriver {
	TrafficCar::TrafficCar(int _damage, int _cash) :damage(_damage), cash(_cash)
	{

	}


	TrafficCar::~TrafficCar()
	{
	}
}