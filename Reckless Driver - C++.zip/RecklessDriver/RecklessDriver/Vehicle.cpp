#include "Vehicle.h"


namespace RecklessDriver {
	Vehicle::Vehicle(int _damage, int _cash) :damage(_damage), cash(_cash)
	{

	}


	Vehicle::~Vehicle()
	{
	}
}