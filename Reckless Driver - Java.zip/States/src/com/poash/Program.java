package com.poash;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lamp lamp = new Lamp() ;
		lamp.SwitchOn();
		lamp.SwitchOn();
		lamp.SwitchOff();
		lamp.SwitchOff();
	}

}
